from flask import Flask, render_template, jsonify
import sqlite3

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/impacto")
def impacto():
    return render_template("impacto.html")

@app.route("/proyectos")
def proyectos():
    return render_template("proyectos.html")

@app.route("/participa")
def participa():
    return render_template("participa.html")

@app.route("/contacto")
def contacto():
    return render_template("contacto.html")

@app.route("/listaProy")
def listaProy():
    conexion = sqlite3.connect("eco.db")
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM proyectos") 
    resultado = cursor.fetchall()
    conexion.close()
    return jsonify(resultado)

if __name__ == "__main__":
    app.run(debug=True)